<?php
/**
 * Template for Footer CPT single page
 *
 * @package gostudy-core\includes\post-types
 * @author RaisTheme <help.raistheme@gmail.com>
 * @since 1.0.0
 */

get_header();

get_footer();
